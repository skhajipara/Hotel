from flask import Flask, render_template, request, redirect, url_for, session, flash  # Importing the necessary libraries
import sqlite3  # Import for SQL
import smtplib  # Import for email
from email.message import EmailMessage  # Import for email
from datetime import datetime, timedelta  # Import for date and time
from pathlib import Path  # Import for file path
from dotenv import load_dotenv
import os
from functools import wraps

load_dotenv()
os.getenv("EMAIL_USER")
os.getenv("EMAIL_PASS")

app = Flask(__name__, template_folder='templates')

# Session config
app.secret_key = 'your_secret_key_here'
app.permanent_session_lifetime = timedelta(hours=24)

# For pdf location
pdf_location = Path("Gujarati menu.pdf")
pdf_location1 = Path("English menu.pdf")

# Email send setup
def send_email_notification(to_email, customer_name, subject, body, attach_pdf=False, attach_pdf1=False):
    sender_email = os.getenv("EMAIL_USER")  # email sender
    sender_password = os.getenv("EMAIL_PASS")

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = to_email
    msg.set_content(body)

    # Attach pdf setup
    if attach_pdf and pdf_location.exists():
        with open(pdf_location, 'rb') as f:
            msg.add_attachment(f.read(), maintype='application', subtype='pdf', filename="S.K.Hostels_Kathiyawadi_Menu.pdf")

    if attach_pdf1 and pdf_location1.exists():
        with open(pdf_location1, 'rb') as f:
            msg.add_attachment(f.read(), maintype='application', subtype='pdf', filename="S.K.Hotels_Menu.pdf")

    # mail sending use smtplib
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(sender_email, sender_password)
        smtp.send_message(msg)

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            flash("⚠️ Please log in to access this page.")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# for connect with html
@app.route('/')
def home():
    return render_template('Kathiyawad.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        Email = request.form.get('Email')
        Password = request.form.get('Password')
        if Email and Password:
            with sqlite3.connect('table.db') as conn:  # Connect to the database
                cursor = conn.cursor()
                # Login table
                cursor.execute('''CREATE TABLE IF NOT EXISTS Login (
                    Customer_Name TEXT NOT NULL,
                    Email TEXT NOT NULL,
                    Mobile_No INTEGER NOT NULL,
                    Password TEXT NOT NULL);''')
                cursor.execute("SELECT Customer_Name, Password FROM Login WHERE Email = ?", (Email,))
                result = cursor.fetchone()

            if result:  # Check if the user exists or not
                customer_name, stored_password = result
                if stored_password == Password:
                    # Set session on successful login
                    session.permanent = True
                    session['user'] = customer_name
                    session['email'] = Email

                    subject = "🔐 Login Notification"
                    body = f"""\U0001f44b Hello {customer_name},

✅ You have successfully logged in to **S.K.Hotels Group**!

Please enjoy your meal at our Hotel.

🍽️ Explore the Menu  
🛒 Place Your Order  
🪑  Book a Table  
🚚 Get Food Delivered  
🛏️ Room Book

🕰️ Login Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}



Warm Regards,
❤️ Team S.K.Hotels"""
                    send_email_notification(Email, customer_name, subject, body, attach_pdf=True, attach_pdf1=True)
                    flash("✅ Login successful!")
                    return redirect(url_for('home'))

                else:  # Check if the password is correct or not
                    flash("❌ Incorrect email or password. Please try again.")
                    return redirect(url_for('login'))

            else:  # Check if the user exists or not
                flash("⚠️ You don't have an account. Please sign up first.")
                return redirect(url_for('signup'))

    return render_template('login.html')  # Return the login page 

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        Customer_Name = request.form.get('Customer_Name')
        Email = request.form.get('Email')
        Mobile_No = request.form.get('Mobile_No')
        Password = request.form.get('Password')
        if Customer_Name and Email and Mobile_No and Password:
            with sqlite3.connect('table.db') as conn:  # Connect to database. It will be created if it doesn't exist.
                cursor = conn.cursor()
                # Create table if it doesn't exist
                cursor.execute('''CREATE TABLE IF NOT EXISTS Login (
                    Customer_Name TEXT NOT NULL,
                    Email TEXT NOT NULL,
                    Mobile_No INTEGER NOT NULL,
                    Password TEXT NOT NULL);''')
                
                # Check if account already exists
                cursor.execute('SELECT * FROM Login WHERE Email = ?', (Email,))
                if cursor.fetchone():
                    flash("⚠️ You already have an account. Please login.")
                    return redirect(url_for('login'))

                cursor.execute('''INSERT INTO Login (Customer_Name, Email, Mobile_No, Password)
                                  VALUES (?, ?, ?, ?)''', (Customer_Name, Email, Mobile_No, Password))

            # mail send to customer for Account create at a time
            subject = "📝 Account Created Successfully"
            body = f"""\U0001f44b Hello {Customer_Name},

🎉 Your account has been created at **S.K.Hotels Group**!

🍽️ Explore the Menu  
🛒 Place Your Order  
🪑 Book a Table  
🚚 Get Food Delivered
🛏️ Room Book  



Warm Regards,
❤️ Team S.K.Hotels"""
            send_email_notification(Email, Customer_Name, subject, body)
            flash("✅ Account created successfully!")
            return redirect(url_for('login'))

    return render_template('signup.html')  # Return the signup page

@app.route('/forget', methods=['GET', 'POST'])
def forget_password():
    if request.method == 'POST':
        Email = request.form.get('Email')
        Mobile_No = request.form.get('Mobile_No')

        if Email and Mobile_No:
            with sqlite3.connect('table.db') as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT Customer_Name, Password FROM Login WHERE Email = ? AND Mobile_No = ?", (Email, Mobile_No))
                result = cursor.fetchone()

                if result:
                    customer_name, password = result
                    subject = "🔑 Password Recovery - S.K.Hotels Group"
                    body = f"""\U0001f44b Hello {customer_name},

🛡️ You requested to recover your password from **S.K.Hotels Group**.

📞 Contact: {Mobile_No}
🔐 Your Password: {password}



Warm Regards,
❤️ Team S.K.Hotels"""
                    send_email_notification(Email, customer_name, subject, body)
                    flash("✅ Password sent to your email.")
                    return redirect(url_for('login'))
                else:
                    flash("⚠️ No account found. Please sign up first.")
                    return redirect(url_for('signup'))

    return render_template('forget.html')

# All route are link page with html file
@app.route('/menu')
@login_required
def menu():
    return render_template('menu.html')

@app.route('/booking')
@login_required
def booking():
    return render_template('booking.html')

@app.route('/order')
@login_required
def order():
    return render_template('order.html')

@app.route('/delivery')
@login_required
def delivery():
    return render_template('delivery.html')

# Room booking route
@app.route('/room', methods=['GET', 'POST'])
@login_required
def room_booking():
    if request.method == 'POST':
        Customer_Name = session['user']
        Email = session['email']
        MO_Number = request.form.get('MO_Number')
        room_no = request.form.get('Room_No')
        Member = request.form.get('Member')
        entry_time = request.form.get('Entry_Time')
        exit_time = request.form.get('Exit_Time')

        try:
            if not all([Customer_Name, Email, MO_Number, room_no, Member, entry_time, exit_time]):
                flash("⚠️ All fields are required.")
                return redirect(url_for('room_booking'))

            with sqlite3.connect('table.db') as conn:
                cursor = conn.cursor()

                # Check if user is registered
                cursor.execute('SELECT * FROM Login WHERE Customer_Name = ? AND Email = ? AND Mobile_No = ?', 
                               (Customer_Name, Email, MO_Number))
                if not cursor.fetchone():
                    flash("⚠️ Please login first (you are not registered).")
                    return redirect(url_for('login'))

                # Convert string times to datetime objects
                entry = datetime.strptime(entry_time, "%Y-%m-%dT%H:%M")
                exit = datetime.strptime(exit_time, "%Y-%m-%dT%H:%M")

                if exit <= entry or (exit - entry).total_seconds() < 3600:
                    flash("⚠️ You must book the room for a minimum of 1 hour.")
                    return redirect(url_for('room_booking'))

                booking_time = datetime.strptime(entry_time, '%Y-%m-%dT%H:%M')
                if booking_time < datetime.now():
                    flash("⚠️ You cannot book a room in the past. Please choose a future time.")
                    return redirect(url_for('room_booking'))

                # Validate room number
                room = int(room_no)
                valid_ranges = list(range(101, 131)) + list(range(201, 231)) + list(range(301, 331)) + list(range(401, 441))
                if room not in valid_ranges:
                    flash("⚠️ Room number must be between 101-130, 201-230, 301-330, 401-440")
                    return redirect(url_for('room_booking'))

                # Create RoomBooking table if not exists
                cursor.execute('''CREATE TABLE IF NOT EXISTS RoomBooking (
                    Customer_Name TEXT, Email TEXT, Mobile_No TEXT,
                    Room_No INTEGER, Member INTEGER, Entry_Time TEXT, Exit_Time TEXT);''')

                # Check if room is booked and still occupied at desired entry time
                cursor.execute('''
                    SELECT * FROM RoomBooking 
                    WHERE Room_No = ? AND Exit_Time > ?
                ''', (room_no, entry_time))

                if cursor.fetchone():
                    flash("⚠️ This room is already booked for the selected time.")
                    return redirect(url_for('room_booking'))

                # Insert booking
                cursor.execute("INSERT INTO RoomBooking VALUES (?, ?, ?, ?, ?, ?, ?)",
                               (Customer_Name, Email, MO_Number, room_no, Member, entry_time, exit_time))

            # Send confirmation email
            subject = "🛏️ Room Booking Confirmation"
            body = f"""👋 Hello {Customer_Name},

✅ Your room has been booked successfully!

🏨 Room No: {room_no}  
👥 Members: {Member}  
🕰️ From: {entry_time}  
⏳ To: {exit_time}
📞 Contact: {MO_Number}



Warm Regards,  
❤️ Team S.K.Hotels"""

            send_email_notification(Email, Customer_Name, subject, body)

            flash("✅ Room booked successfully!")
            return redirect(url_for('home'))

        except Exception as e:
            flash(f"⚠️ Error: {str(e)}")
            return redirect(url_for('room_booking'))

    return render_template('room booking.html')  # Return the room booking page

@app.route('/submit', methods=['POST'])
@login_required
def submit():
    Customer_Name = session['user']
    Email = session['email']
    MO_Number = request.form.get('MO_Number')

    try:
        with sqlite3.connect('table.db', timeout=10) as conn:  # Connect to database. It will be created if it doesn't exist.
            cursor = conn.cursor()

            # for table booking
            if Email and MO_Number and request.form.get('Table_No') and request.form.get('Date_Time'):
                Table_No = request.form.get('Table_No')
                Member = request.form.get('Member')
                Date_Time = request.form.get('Date_Time')

                cursor.execute('SELECT * FROM Login WHERE Customer_Name = ? AND Email = ? AND Mobile_No = ?', 
                               (Customer_Name, Email, MO_Number))
                if not cursor.fetchone():  # If customer is not in database
                    flash("⚠️ Please login first (you are not registered).")
                    return redirect(url_for('login'))

                # check date and time
                try:
                    booking_time = datetime.strptime(Date_Time, '%Y-%m-%dT%H:%M')
                    if booking_time < datetime.now():
                        flash("⚠️ You cannot book a table in the past. Please choose a future time.")
                        return redirect(url_for('booking'))

                except ValueError:  # If date and time is not in correct format
                    flash("⚠️ Invalid date/time format. Please select a valid date.")
                    return redirect(url_for('booking'))

                # Booking table database
                cursor.execute('''CREATE TABLE IF NOT EXISTS Booking (
                    Customer_Name TEXT, Email TEXT, MO_Number INTEGER,
                    Table_No INTEGER, Member INTEGER, Date_Time TEXT);''')
                cursor.execute("SELECT * FROM Booking WHERE Table_No = ? AND Date_Time = ?", (Table_No, Date_Time))
                if cursor.fetchone():  # check condition if table is already booked
                    flash("⚠️ Table already booked at that time.")
                    return redirect(url_for('booking'))
                else:  # if table is not booked, insert data into database
                    cursor.execute('INSERT INTO Booking VALUES (?, ?, ?, ?, ?, ?)', 
                                   (Customer_Name, Email, MO_Number, Table_No, Member, Date_Time))

                    if Email:
                        # mail send to customer for Table booking time
                        subject = "🪑 Table Booking Confirmation"
                        body = f"""\U0001f44b Hello {Customer_Name},

✅ Your table has been booked at **S.K.Hotel Group**!

🪑 Table No: {Table_No}  
👥 Members: {Member}  
📆 Date & Time: {Date_Time}



Warm Regards,
❤️ Team S.K.Hotels"""
                        send_email_notification(Email, Customer_Name, subject, body, attach_pdf=True, attach_pdf1=True)
                    flash("✅ Booking successful!")
                    return redirect(url_for('home'))

            # for order page
            elif request.form.get('Table_No') and request.form.get('Order'):
                Table_No = request.form.get('Table_No')
                Order = request.form.get('Order')

                cursor.execute('SELECT * FROM Login WHERE Customer_Name = ?', (Customer_Name,))
                if not cursor.fetchone():
                    flash("⚠️ Please login first.")
                    return redirect(url_for('login'))

                # table order details
                cursor.execute('''CREATE TABLE IF NOT EXISTS Orders_Details (
                    Customer_Name TEXT, Email TEXT NOT NULL, Table_No INTEGER, "Order" TEXT);''')
                cursor.execute('SELECT * FROM Orders_Details WHERE Table_No = ? AND "Order" = ?', (Table_No, Order))
                if cursor.fetchone():  # check condition if order is already placed
                    flash("⚠️ You gave this order already!")
                    return redirect(url_for('order'))
                else:  # if order is not placed, insert data into database
                    cursor.execute('INSERT INTO Orders_Details VALUES (?, ?, ?, ?)', (Customer_Name, Email, Table_No, Order))

                    if Email:
                        # mail send to customer for Order
                        subject = "🛒 Order Confirmation"
                        body = f"""\U0001f44b Hello {Customer_Name},

✅ Your order has been placed!

🪑 Table No: {Table_No}  
📝 Order: {Order}

Please wait a while.....



Warm Regards,
❤️ Team S.K.Hotels"""
                        send_email_notification(Email, Customer_Name, subject, body)
                    flash("✅ Your order has been placed successfully.")
                    return redirect(url_for('home'))

            # Home Delivery page
            elif request.form.get('Address'):
                Mobile_Number = request.form.get('Mobile_Number')
                Order = request.form.get('Order')
                Address = request.form.get('Address')

                # check if customer is login or not
                cursor.execute('SELECT * FROM Login WHERE Customer_Name = ? AND Mobile_No = ?', (Customer_Name, Mobile_Number))
                if not cursor.fetchone():
                    flash("⚠️ Please login first (you are not registered).")
                    return redirect(url_for('login'))

                # home delivery order details
                cursor.execute('''CREATE TABLE IF NOT EXISTS Delivery (
                    Customer_Name TEXT, Mobile_Number INTEGER, "Order" TEXT, Address TEXT);''')
                cursor.execute('SELECT * FROM Delivery WHERE Mobile_Number = ? AND "Order" = ?', (Mobile_Number, Order))
                if cursor.fetchone():  # check condition if order is already placed
                    flash("⚠️ You gave this order already!")
                    return redirect(url_for('order'))
                else:  # if order is not placed, insert data into database
                    cursor.execute('INSERT INTO Delivery VALUES (?, ?, ?, ?)', (Customer_Name, Mobile_Number, Order, Address))

                    if Email:
                        # mail send to customer for Delivery
                        subject = "🚚 Delivery Order Confirmation"
                        body = f"""\U0001f44b Hello {Customer_Name},

✅ Your delivery order has been placed!

Your order is our responsibility,

📦 Order: {Order}  
📍 Address: {Address}  
📞 Contact: {Mobile_Number}

Please wait a while.....



Warm Regards,
❤️ Team S.K.Hotels"""
                        send_email_notification(Email, Customer_Name, subject, body)
                    flash("✅ Your delivery order is confirmed.")
                    return redirect(url_for('home'))

    except sqlite3.OperationalError as e:  # if database is not created
        flash(f"⚠️ Database Error: {str(e)}")
        return redirect(url_for('home'))

    flash("⚠️ Invalid submission. Please try again.")
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
